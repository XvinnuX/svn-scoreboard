![SEVEN DEVELOPMENT ](https://cdn.discordapp.com/attachments/1001711291548827721/1045763109731717201/image.png)

Join my Discord for updates, support, and special early testing!

 https://discord.gg/Uwg7Jpr8xC


PREVIEW : https://youtu.be/eGIeBICHZTg



# Key Features
* STEAM REQUIRED
* ACTIVE PLAYERS 
* ACTIVE JOBS PLAYER
* RECENT DISCONNECT
* WORKING AFTER DEAD
* ROBERRY STATUS
* PLAYER PING , NAME , ID
* HIGHLY OPTIMIZED 


# INSTALLATION

# STEP 1

GO TO SERVER CFG AND ADD THIS

set steam_webApiKey "6E81DF144AE14E165E866B06D0889E00"

# STEP 2

  [standalone]\connectqueue\server\sv_queue_config    --NAVIGATE

  Config.RequireSteam = false --- SET IT TO TRUE

# STEP 3

go to qb-ambulancejob\client\dead.lua  and ADD THIS LINE


EnableControlAction(0, 303, true)


--- SEVEN DEVELOPMENT : JOIN US FOR PAID / FREE SCRIPTS --











