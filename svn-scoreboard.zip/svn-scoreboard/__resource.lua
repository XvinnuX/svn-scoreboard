resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

author 'Nilesh gaming#4738'
description 'svn-scoreboard'

-- SEVEN DEVELOPMENT

client_scripts {
	'scoreboard/cl_scoreboard.lua',
	'scoreboard/warmenu.lua',
}

server_scripts {
	'scoreboard/sv_scoreboard.lua',
}